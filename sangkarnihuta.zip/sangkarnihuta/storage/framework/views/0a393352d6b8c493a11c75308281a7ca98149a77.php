<?php $__env->startSection('title', 'Peraturan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-5 mb-5">Buku Peraturan</h2>
        <p>
            Peraturan Desa adalah peraturan perundang-undangan yang ditetapkan oleh Kepala Desa bersama Badan Permusyawaratan Desa. 
            Peraturan desa tidak boleh bertentangan dengan kepentingan umum dan/atau peraturan perundang-undangan yang lebih tinggi. 
            Jenis dan variasi peraturan desa yang dibuat dan diundangkan tergantung pada kebutuhan aparatur pemerintah desa. Untuk itu dapat kita lihat informasi dari Buku peraturan Desa berikut.
        </p>
        <!-- Button Tambah Data -->
        <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('rules.create')); ?>" class="btn btn-primary">Tambah Data</a>
            </div>
        </div>
        <?php endif; ?>
        <!-- Akhir Button Tambah Data -->
        <br>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered w-100">
                    <thead style="background-color: #229681;">
                        <tr>
                            <th>No</th>
                            <th>Jenis Peraturan</th>
                            <th>Nomor Peraturan</th>
                            <th>Tanggal Peraturan</th>
                            <th>Tentang</th>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->number); ?></td>
                                <td><?php echo e($item->date); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <td>
                                        <a href=<?php echo e(route('rules.edit', $item->id)); ?> class="btn btn-warning">Edit</a>
                                        <a href="javascript:;" onclick="hapus('<?php echo e(route('rules.destroy', $item->id)); ?>')"
                                            class="btn btn-danger">Hapus
                                        </a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br><br>
        <p>Total : <?php echo e($collection->count()); ?></p>
        <div class="col-md-12" align="end">
            <?php echo e($collection->links('components.pagination')); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PA\sangkarnihuta\resources\views/pages/rules/main.blade.php ENDPATH**/ ?>