<?php $__env->startSection('title', 'Buku Agenda'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-5 mb-5">Buku Agenda</h2>
        <p>
            Buku agenda merupakan buku yang digunakan untuk mencatat semua surat surat keluar masuk dalam waktu satu tahun atau periode
            tertentu dalam kelurahan sangkar ni huta.
            Dengan adanya buku agenda untuk melakukan penomoran dalam pembuatan surat akan menjadi lebih mudah karena dengan adanya buku agenda,
            surat surat sebelumnya dan dapat memudahkan pencarian berkas-berkas tertentu karena detail dari setiap surat masuk maupun surat keluar
            dapat di indetifikasikan dengan mudah dan tetulis secara berurutan.
        </p>
        <!-- Button Tambah Data -->
        <?php if(Auth::user()->role == 'admin'): ?>
            <div class="row">
                <div class="col-md-12">
                    <a href="<?php echo e(route('agendas.create')); ?>" class="btn btn-primary">Tambah Data</a>
                </div>
            </div>
        <?php endif; ?>

        <!-- Akhir Button Tambah Data -->
        <br>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered w-100">
                    <thead style="background-color: #229681;">
                        <tr>
                            <th>Tanggal Terima</th>
                            <th>Nomor Agenda</th>
                            <th>Nomor Surat</th>
                            <th>Tanggal Pengiriman Surat</th>
                            <th>Isi Ringkasan</th>
                            <th>Dari</th>
                            <th>Kepada</th>
                            <th>Keterangan</th>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->date_of_agenda); ?></td>
                                <td><?php echo e($item->number_of_agenda); ?></td>
                                <td><?php echo e($item->number_of_letter); ?></td>
                                <td><?php echo e($item->date_of_letter); ?></td>
                                <td><?php echo e($item->summary); ?></td>
                                <td><?php echo e($item->from); ?></td>
                                <td><?php echo e($item->to); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <td>
                                        <a href=<?php echo e(route('agendas.edit', $item->id)); ?> class="btn btn-warning">Edit</a>
                                        <a href="javascript:;"
                                            onclick="hapus('<?php echo e(route('agendas.destroy', $item->id)); ?>')"
                                            class="btn btn-danger">Hapus
                                        </a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br><br>
        <p>Total : <?php echo e($collection->count()); ?></p>
        <div class="col-md-12" align="end">
            <?php echo e($collection->links('components.pagination')); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PA\sangkarnihuta\resources\views/pages/agendas/main.blade.php ENDPATH**/ ?>