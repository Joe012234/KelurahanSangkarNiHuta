<nav class="navbar navbar-expand-lg" style="background-color: #229681">
    <div class="container">
        <a class="navbar-brand" href="#">
            <img src="<?php echo e(asset('img/logo.png')); ?>" alt="logo" width="45" style="float: left;" class="me-3">
            <p class="text-white pt-3">Kelurahan Sangkar NiHuta</p>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link text-white <?php echo e(request()->is('/') ? 'active' : ''); ?>"
                        href="<?php echo e(route('home')); ?>">Home</a>
                </li>
                <li
                    class="nav-item dropdown <?php echo e(request()->is('agendas.*') || request()->is('expeditions.*') || request()->is('rules.*') || request()->is('services.*') ? 'active' : ''); ?>">
                    <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Administrasi
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #DAF8F2;">
                        <li>
                            <a class="dropdown-item text-success <?php echo e(request()->is('agendas.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('agendas.index')); ?>">
                                Buku Agenda
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item text-success <?php echo e(request()->is('expeditions.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('expeditions.index')); ?>">
                                Buku Ekspedisi
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item text-success <?php echo e(request()->is('rules.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('rules.index')); ?>">
                                Buku Peraturan Desa
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item text-success <?php echo e(request()->is('services.*') ? 'active' : ''); ?>"
                                href="<?php echo e(route('services.index')); ?>">
                                Pelayanan Admnistrasi </a>
                        </li>
                    </ul>
                </li>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->role == 'user'): ?>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="<?php echo e(route('contact')); ?>">Contact</a>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item dropdown" style="background-color: #229681">
                        <a class="nav-link dropdown-toggle text-white" href="#" id="navbarDropdown" role="button"
                            data-bs-toggle="dropdown" aria-expanded="false">Hi, <?php echo e(Auth::user()->username); ?>

                            <i class="fa fa-user-circle"></i>
                        </a>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="background-color: #DAF8F2;">
                            <li><a class="dropdown-item text-success" href="<?php echo e(route('profile')); ?>">Profile</a></li>
                            <li><a class="dropdown-item text-success" href="<?php echo e(route('logout')); ?>">Logout</a></li>
                        </ul>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>

</nav>
<!-- Akhir Navbar -->
<?php /**PATH D:\PA\sangkarnihuta\resources\views/layouts/header.blade.php ENDPATH**/ ?>