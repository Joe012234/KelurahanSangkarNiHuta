<?php $__env->startSection('title', 'Buku Ekspedisi'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-5 mb-5">Buku Ekspedisi</h2>
        <p>
            Buku Ekspedisi adalah "Buku Pengantar Surat" yang digunakan untuk mencatat daftar pengiriman surat kepada pihak lain sehingga 
            lebih rapi dan digunakan sebagai bukti bahwa surat sudah dikirim atau diterima dalam Kelurahan Sangkat Ni Huta.
            <ol type="1">
                <li>Untuk menjamin keselamatan surat surat yang dikirimkan ke alamat yang dituju.</li>
                <li>Untuk tanda bukti bagi pengantar surat bahwa surat itu benar-benar disampaikan kepada yang bersangkutan.</li>
                <li>Tertib administrasi.</li>
            </ol>   
        </p>
        <!-- Button Tambah Data -->
        <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('expeditions.create')); ?>" class="btn btn-primary">Tambah Data</a>
            </div>
        </div>
        <?php endif; ?>
        <!-- Akhir Button Tambah Data -->
        <br>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered w-100">
                    <thead style="background-color: #229681;">
                        <tr>
                            <th>Tanggal Pengiriman Surat</th>
                            <th>Nomor Surat </th>
                            <th>Perihal</th>
                            <th>Nama Pengirim</th>
                            <th>Nama Penerima</th>
                            <th>Keterangan</th>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->date); ?></td>
                                <td><?php echo e($item->number); ?></td>
                                <td><?php echo e($item->subject); ?></td>
                                <td><?php echo e($item->from); ?></td>
                                <td><?php echo e($item->to); ?></td>
                                <td><?php echo e($item->description); ?></td>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <td>
                                        <a href=<?php echo e(route('expeditions.edit', $item->id)); ?> class="btn btn-warning">Edit</a>
                                        <a href="javascript:;"
                                            onclick="hapus('<?php echo e(route('expeditions.destroy', $item->id)); ?>')"
                                            class="btn btn-danger">Hapus</a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br><br>
        <p>Total : <?php echo e($collection->count()); ?></p>
        <div class="col-md-12" align="end">
            <?php echo e($collection->links('components.pagination')); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PA\sangkarnihuta\resources\views/pages/expeditions/main.blade.php ENDPATH**/ ?>