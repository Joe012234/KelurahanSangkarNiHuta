<?php $__env->startSection('title', 'Layanan'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mt-5 mb-5">Buku Administrasi</h2>
        <p>
            Berikut adalah informasi-informasi yang ditampilkan untuk dapat dipahami syaratnya sesuai dengan jenis pelayanan yang masyarakat ingin ketahui.
        </p>
        <!-- Button Tambah Data -->
        <?php if(Auth::user()->role == 'admin'): ?>
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary">Tambah Data</a>
            </div>
        </div>
        <?php endif; ?>
        <!-- Akhir Button Tambah Data -->
        <br>
        <div class="row">
            <div class="col-md-12">
                <table class="table table-bordered w-100">
                    <thead style="background-color: #229681;">
                        <tr>
                            <th>Jenis Layanan</th>
                            <th>Dokumen</th>
                            <th>Syarat</th>
                            <th>Biaya</th>
                            <th>Proses</th>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <th>Aksi</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->document); ?></td>
                                <td><?php echo e($item->condition); ?></td>
                                <td><?php echo e($item->cost); ?></td>
                                <td><?php echo e($item->process); ?></td>
                                <?php if(Auth::user()->role == 'admin'): ?>
                                    <td>
                                        <a href=<?php echo e(route('services.edit', $item->id)); ?> class="btn btn-warning">Edit</a>
                                        <a href="javascript:;"
                                            onclick="hapus('<?php echo e(route('services.destroy', $item->id)); ?>')"
                                            class="btn btn-danger">Hapus
                                        </a>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <br><br>
        <p>Total : <?php echo e($collection->count()); ?></p>
        <div class="col-md-12" align="end">
            <?php echo e($collection->links('components.pagination')); ?>

        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PA\sangkarnihuta\resources\views/pages/services/main.blade.php ENDPATH**/ ?>